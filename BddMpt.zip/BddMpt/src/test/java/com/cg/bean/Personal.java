package com.cg.bean;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

public class Personal {

	@FindBy(id="fname")
	private WebElement fname;
	
	@FindBy(id="lname")
	private WebElement lname;
	
	@FindBy(id="email")
	private WebElement email;
	
	@FindBy(id="mobile")
	private WebElement mobile;
	
	@FindBy(id="address1")
	private WebElement address1;
	
	@FindBy(id="address2")
	private WebElement address2;
	
	@FindBy(id="city")
	private WebElement city;

	@FindBy(id="state")
	private WebElement state;
	
	@FindBy(id="next")
	WebElement next;

	public String getFname() {
		return fname.getAttribute("value");
	}

	public void setFname(String fname) {
		this.fname.sendKeys(fname);
	}

	public String getLname() {
		return fname.getAttribute("value");
	}

	public void setLname(String lname) {
		this.lname.sendKeys(lname);
	}

	public String getEmail() {
		return this.email.getAttribute("value");
	}

	public void setEmail(String email) {
		this.email.sendKeys(email);
	}

	public String getMobile() {
		return this.mobile.getAttribute("value");
	}

	public void setMobile(String mobile) {
		this.mobile.sendKeys(mobile);
	}

	public String getAddress1() {
		return this.address1.getAttribute("value");
	}

	public void setAddress1(String address1) {
		this.address1.sendKeys(address1);
	}

	public String getAddress2() {
		return this.address2.getAttribute("value");
	}

	public void setAddress2(String address2) {
		this.address2.sendKeys(address2);
	}

	public void clickCity(int i) {
		Select select = new Select(city);
		select.selectByIndex(i);
	}
	
	public void clickState(int i) {
		Select select = new Select(state);
		select.selectByIndex(i);;
	}
	
	public void clickNext() {
		next.click();
	}
}
