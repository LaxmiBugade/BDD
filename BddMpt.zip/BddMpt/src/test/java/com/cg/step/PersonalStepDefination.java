package com.cg.step;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.bean.Personal;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class PersonalStepDefination {

	private WebDriver driver;
	private Personal personal;

	@Before
	public void init() {
		// Instantiate driver
		System.setProperty("webdriver.chrome.driver", "C:\\Laxmi\\Module 4\\mydriver\\chromedriver.exe");
		driver = new ChromeDriver();
	}

	@After
	public void destroy() {
		driver.quit();
	}

	@Given("^User is on Personal Details Page$")
	public void user_is_on_Personal_Details_Page() throws Throwable {
		// Open login page in chrome
		String url = "file:///C://Users//lbugade//BDD//BddMpt//html//PersonalDetails.html";
		driver.get(url);
		personal = new Personal();
		PageFactory.initElements(driver, personal);
	}

	@When("^user enters first name$")
	public void user_enters_first_name() throws Throwable {
		personal.setFname(" ");
	}

	@Then("^validate first name$")
	public void validate_first_name() throws Throwable {
		personal.clickNext();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
	}

	@When("^user enters last name$")
	public void user_enters_last_name() throws Throwable {
		personal.setFname("Laxmi");
		personal.setLname(" ");
	}

	@Then("^validate last name$")
	public void validate_last_name() throws Throwable {
		personal.clickNext();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
	}

	@When("^user enters email$")
	public void user_enters_email() throws Throwable {
		personal.setFname("Laxmi");
		personal.setLname("Bugade");
		personal.setEmail(" ");
	}

	@Then("^validate email$")
	public void validate_email() throws Throwable {
		personal.clickNext();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
	}

	@When("^user enters mobile number$")
	public void user_enters_mobile_number() throws Throwable {
		personal.setFname("Laxmi");
		personal.setLname("Bugade");
		personal.setEmail("laxmi@gmail.com");
		personal.setMobile(" ");
	}

	@Then("^validate mobile$")
	public void validate_mobile() throws Throwable {
		personal.clickNext();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
	}

	@When("^user enters address(\\d+)$")
	public void user_enters_address() throws Throwable {
		personal.setFname("Laxmi");
		personal.setLname("Bugade");
		personal.setEmail("laxmi@gmail.com");
		personal.setMobile("9856131478");
		personal.setAddress1(" ");
	}

	@Then("^validate address(\\d+)$")
	public void validate_address() throws Throwable {
		personal.clickNext();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
	}

	@When("^user select city$")
	public void user_select_city() throws Throwable {
		personal.setFname("Laxmi");
		personal.setLname("Bugade");
		personal.setEmail("laxmi@gmail.com");
		personal.setMobile("985613147");
		personal.setAddress1("Shivcolony");
		personal.setAddress2("Airoli");
		personal.clickCity(0);
	}

	@Then("^validate city$")
	public void validate_city() throws Throwable {
		personal.clickNext();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
	}

	@When("^user select state$")
	public void user_select_state() throws Throwable {
		personal.setFname("Laxmi");
		personal.setLname("Bugade");
		personal.setEmail("laxmi@gmail.com");
		personal.setMobile("985613147");
		personal.setAddress1("Shivcolony");
		personal.setAddress2("Airoli");
		personal.clickCity(1);
		personal.clickState(0);
	}

	@Then("^validate state$")
	public void validate_state() throws Throwable {
		personal.clickNext();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
	}

	@When("^User click next link$")
	public void user_click_next_link() throws Throwable {
		personal.setFname("Laxmi");
		personal.setLname("Bugade");
		personal.setEmail("laxmi@gmail.com");
		personal.setMobile("985613147");
		personal.setAddress1("Shivcolony");
		personal.setAddress2("Airoli");
		personal.clickCity(1);
		personal.clickState(1);
	}

	@Then("^show successful alert$")
	public void show_successful_alert() throws Throwable {
		personal.clickNext();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
	}
}
