package com.cg.bean;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class Equipment {
	
	@FindBy(id="txtpurchaseMethod")
	WebElement purchaseMethod;
	
	@FindBy(id="txtsequenceNumber")
	WebElement sequenceNumber;
	
	@FindBy(id="txtequipmentCode")
	WebElement equipmentCode;
	
	@FindBy(id="txtdeptId")
	WebElement deptId;
	
	@FindBy(id="txtuseStatus")
	WebElement useStatus;
	
	@FindBy(id="txtcostCenter")
	WebElement costCenter;
	
	@FindBy(id="txtinstallDate")
	WebElement installDate;
	
	@FindBy(name="txtauditIndictor")
	WebElement auditIndictor;
	
	@FindBy(name="txtauditDate")
	WebElement auditDate;
	
	@FindBy(name="txtstock")
	WebElement stock;

	public WebElement getPurchaseMethod() {
		return purchaseMethod;
	}

	public void setPurchaseMethod(WebElement purchaseMethod) {
		this.purchaseMethod = purchaseMethod;
	}

	public WebElement getSequenceNumber() {
		return sequenceNumber;
	}

	public void setSequenceNumber(WebElement sequenceNumber) {
		this.sequenceNumber = sequenceNumber;
	}

	public WebElement getEquipmentCode() {
		return equipmentCode;
	}

	public void setEquipmentCode(WebElement equipmentCode) {
		this.equipmentCode = equipmentCode;
	}

	public WebElement getDeptId() {
		return deptId;
	}

	public void setDeptId(WebElement deptId) {
		this.deptId = deptId;
	}

	public WebElement getUseStatus() {
		return useStatus;
	}

	public void setUseStatus(WebElement useStatus) {
		this.useStatus = useStatus;
	}

	public WebElement getCostCenter() {
		return costCenter;
	}

	public void setCostCenter(WebElement costCenter) {
		this.costCenter = costCenter;
	}

	public WebElement getInstallDate() {
		return installDate;
	}

	public void setInstallDate(WebElement installDate) {
		this.installDate = installDate;
	}

	public WebElement getAuditIndictor() {
		return auditIndictor;
	}

	public void setAuditIndictor(WebElement auditIndictor) {
		this.auditIndictor = auditIndictor;
	}

	public WebElement getAuditDate() {
		return auditDate;
	}

	public void setAuditDate(WebElement auditDate) {
		this.auditDate = auditDate;
	}

	public WebElement getStock() {
		return stock;
	}

	public void setStock(WebElement stock) {
		this.stock = stock;
	}
	
	
}
